package es.cic.examen_parcial;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import com.fasterxml.jackson.databind.ObjectMapper;

import es.cic.examen_parcial.Entity.Director;
import es.cic.examen_parcial.Entity.Pelicula;
import es.cic.examen_parcial.Repository.DirectorRepository;

@SpringBootTest
@AutoConfigureMockMvc
class DirectorControllerTest {

	@Autowired
	private DirectorRepository directorRepository;

	@Autowired
	private ObjectMapper objectMapper;

    @Autowired
    private MockMvc mvc;

	private Director director;
	List<Pelicula> peliculas;

	@BeforeEach
	public void setUp() {
		director = new Director();
		peliculas = new ArrayList<>();
		

		Pelicula pelicula = new Pelicula();
		pelicula.setTitulo("El Imperio Contraataca");
		pelicula.setDirector(director);

		director.getPeliculas().add(pelicula);
		directorRepository.save(director);
		directorRepository.flush();
	}

	@Test
	void testLeer() throws Exception {

		MvcResult mvcResult = mvc.perform(get("/api/director/{1}", director.getId())
			.contentType(MediaType.APPLICATION_JSON))
			.andDo(print())
			.andExpect(status().isOk())
			.andExpect(jsonPath("$.id").value(director.getId()))
			.andReturn();

		String body = mvcResult.getResponse().getContentAsString();
		Director directorResultado = objectMapper.readValue(body, Director.class);

		assertTrue(directorResultado.getPeliculas().size() >= 1);

	}

}