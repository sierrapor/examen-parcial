package es.cic.examen_parcial.Ejercicio1;

public interface ConPuertas {

    public default boolean AbrirPuerta(){
        return true;
    }
    public default boolean cerrarPuerta(){
        return false;
    }

}
