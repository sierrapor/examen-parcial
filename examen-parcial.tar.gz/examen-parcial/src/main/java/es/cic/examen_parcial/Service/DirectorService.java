package es.cic.examen_parcial.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import es.cic.examen_parcial.Entity.Director;
import es.cic.examen_parcial.Repository.DirectorRepository;

@Service
@Transactional
public class DirectorService {

    @Autowired
    private DirectorRepository directorRepository;

    public long crear(Director director){
        directorRepository.save(director);
        return director.getId();
    }

    @Transactional(readOnly = true)
    public Director leer(long id){
        return directorRepository.findById(id)
        .orElseThrow(() -> new RuntimeException("director no encontrado"));
    }

    @Transactional(readOnly = true)
    public List<Director> listar(){
        Iterable<Director> todos = directorRepository.findAll();
        List<Director> lista = new ArrayList<>();
        todos.forEach(lista::add);
        
        return lista;
    }

    public void actualizar(Director director) {
        directorRepository.save(director);
    }

    public void borrar(long id) {
        directorRepository.deleteById(id);
    }

}