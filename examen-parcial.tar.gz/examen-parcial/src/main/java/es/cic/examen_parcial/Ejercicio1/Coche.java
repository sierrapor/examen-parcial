package es.cic.examen_parcial.Ejercicio1;

public class Coche implements ConPuertas{

}
