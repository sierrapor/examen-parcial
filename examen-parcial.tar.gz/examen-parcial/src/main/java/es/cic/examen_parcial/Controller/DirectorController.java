package es.cic.examen_parcial.Controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import es.cic.examen_parcial.Entity.Director;
import es.cic.examen_parcial.Service.DirectorService;


@RestController
@RequestMapping("/api/director")
public class DirectorController {

    @Autowired
    private DirectorService directorService;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public long crear(@RequestBody Director director){
        if (director.getId() != null) {
            throw new RuntimeException("Casi pero no");     
        }

        return directorService.crear(director);
    }

    @GetMapping("/{id}")
    public Director leer(@PathVariable("id") long id){
        return directorService.leer(id);
    }

    @GetMapping
    public List<Director> listar(){
        return directorService.listar();
    }

    @PutMapping
    public void actualizar(Director director){
        if (director.getId() == null) {
            throw new RuntimeException("Casi pero no");     
        }
        directorService.actualizar(director);
    }

    @DeleteMapping
    public void borrar(long id){
        directorService.borrar(id);
    }
}

