package es.cic.examen_parcial.Ejercicio3;

public class Pantalla {

    public String MostrarEnPantalla(Teclado mensaje){

        return mensaje;

    }

}
