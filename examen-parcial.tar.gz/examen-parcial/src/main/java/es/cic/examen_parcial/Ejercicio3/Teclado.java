package es.cic.examen_parcial.Ejercicio3;

public class Teclado {

    String texto;

    public String escribir(){
        
    }

}
