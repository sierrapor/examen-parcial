package es.cic.examen_parcial.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import es.cic.examen_parcial.Entity.Pelicula;
import es.cic.examen_parcial.Repository.PeliculaRepository;

@Service
@Transactional
public class PeliculaService {

    @Autowired
    private PeliculaRepository peliculaRepository;

    public long crear(Pelicula pelicula){
        peliculaRepository.save(pelicula);
        return pelicula.getId();
    }

    @Transactional(readOnly = true)
    public Pelicula leer(long id){
        return peliculaRepository.findById(id)
        .orElseThrow(() -> new RuntimeException("pelicula no encontrada"));
    }

    @Transactional(readOnly = true)
    public List<Pelicula> listar(){
        Iterable<Pelicula> todos = peliculaRepository.findAll();
        List<Pelicula> lista = new ArrayList<>();
        todos.forEach(lista::add);
        
        return lista;
    }

    public void actualizar(Pelicula pelicula) {
        peliculaRepository.save(pelicula);
    }

    public void borrar(long id) {
        peliculaRepository.deleteById(id);
    }

}