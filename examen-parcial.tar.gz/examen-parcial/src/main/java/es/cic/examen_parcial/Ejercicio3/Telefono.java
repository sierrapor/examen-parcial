package es.cic.examen_parcial.Ejercicio3;

public class Telefono {
    private boolean encendido;

    public boolean encender(){
        encendido = true;
        return encendido;
    }
    public boolean apagar(){
        encendido = false;
        return encendido;
    }
}
