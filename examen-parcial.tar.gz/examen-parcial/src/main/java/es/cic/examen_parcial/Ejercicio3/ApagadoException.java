package es.cic.examen_parcial.Ejercicio3;

public class ApagadoException extends RuntimeException {
    public ApagadoException() {
    }

    public ApagadoException(String mensaje) {
        super(mensaje);
    }

    public ApagadoException(String mensaje, Throwable caused) {
        super(mensaje, caused);
    }
}
