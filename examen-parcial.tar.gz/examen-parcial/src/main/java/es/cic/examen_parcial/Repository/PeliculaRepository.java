package es.cic.examen_parcial.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import es.cic.examen_parcial.Entity.Pelicula;

public interface PeliculaRepository extends JpaRepository<Pelicula, Long>{

}
