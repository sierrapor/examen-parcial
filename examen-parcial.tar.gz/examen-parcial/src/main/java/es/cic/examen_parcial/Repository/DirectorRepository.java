package es.cic.examen_parcial.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import es.cic.examen_parcial.Entity.Director;

public interface DirectorRepository extends JpaRepository<Director, Long>{

}
